## Memo game

this game is an example of posible implementations of the Matrix Component: https://github.com/JuanMarchetto/matrix

in order to make it work you should edit de elements array in src/elements.js file with paths to the images that you whant to include in the game

DEMO:https://memofran.netlify.com/
