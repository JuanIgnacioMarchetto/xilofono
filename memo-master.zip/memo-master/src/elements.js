import { shuffle } from "./helpers";
//array off Images' URLs
export const elements = shuffle([]);

export const name = "Memo game";

export const maxLevel = 10;
